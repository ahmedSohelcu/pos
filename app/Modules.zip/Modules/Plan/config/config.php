<?php

return [
    'name' => 'Plan',
];
