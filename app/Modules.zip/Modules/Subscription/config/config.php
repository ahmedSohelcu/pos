<?php

return [
    'name' => 'Subscription',
];
