<?php

return [
    'name' => 'Tenant',
];
